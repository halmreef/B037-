<?php require 'header.php';?>
<div class="page">

<div class="main" style="width:97%">
<div class="images"><img src="img/info.png"></div> 

<div class="userMenu">
    
<div class="alt1"><i class="fas fa-angle-double-left"></i> الأضاحي </div><div class="alt2">100SR</div><div class="alt3">22-1-2018</div>
<div class="alt1"><i class="fas fa-angle-double-left"></i> الحلاقة </div><div class="alt2">15SR</div><div class="alt3">22-1-2018</div>
<div class="alt1"><i class="fas fa-angle-double-left"></i>المواصلات</div><div class="alt2">150SR</div><div class="alt3">22-1-2018</div>
<div class="alt1"><i class="fas fa-angle-double-left"></i>المطاعم</div><div class="alt2">150SR</div><div class="alt3">22-1-2018</div>
<div class="alt1"><i class="fas fa-angle-double-left"></i>سكن</div><div class="alt2">150SR</div><div class="alt3">22-1-2018</div>
<div class="alt1"><i class="fas fa-angle-double-left"></i>كفارة</div><div class="alt2">150SR</div><div class="alt3">22-1-2018</div>
    
</div>    

    
</div><!-- Main END -->




</div>
<?php require 'footer.php';?>
