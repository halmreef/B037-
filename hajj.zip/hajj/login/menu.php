<div class="main_4">

<div class="images" style="width:130px;height:130px;"><img src="img/manager.png"></div> 
<div class="name">مدير النظام
<div class="campNo">الرقم : 1 </div> 
</div>


    
<div class="userMenu" style="width:90%;">
    
<div class="alt1"><i class="fas fa-angle-double-left"></i> آخر دخول : </div><div class="alt2">22-1-2018</div>
    
</div>    

    
</div><!-- Main END -->

<div class="menu">
<ul>
<li><a href="#">لوحة التحكم</a></li>
<li><a href="#">التقارير والاحصائيات</a></li>
    <li><a href="#">المستخدمين</a>
        <ul class="dropMenu">
            <li><a href="users.php">حجاج</a></li>
            <li><a href="users.php">المحلات</a></li>
            <li><a href="users.php">خدمة العملاء</a></li>
        </ul>
    </li>
<li><a href="#">العمليات</a>
        <ul class="dropMenu">
            <li><a href="#">الشراء</a></li>
            <li><a href="#">إعادة الشحن</a></li>
            <li><a href="#">المسترد</a></li>
            <li><a href="#">حوالات</a></li>
        </ul>
</li>
<li><a href="#">الإعدادات</a></li>
</ul>
</div>
