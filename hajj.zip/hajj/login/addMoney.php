<?php require 'header.php';?>
<div class="page">




    
    
<div class="main" style="width:97%;">

<form action="#">
<input type="text" name="number" pattern="[1-9]{2}" placeholder="المبلغ" class="textForm"><br>
<input type="submit" value="إضافة" class="submit">
</form>
    
    
</div><!-- Main END -->



</div>
<?php require 'footer.php';?>
