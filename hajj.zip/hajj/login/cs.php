<?php require 'header.php';?>

<?php


if ( isset($_POST['charge']) )
{
    $money = $_POST['money'];
    $haj_id = $_POST['haj_id'];
    $currency = $_POST['currency'];

    // Covert money
    switch ($currency)
    {
        case 'dollar':
            $money = ($money * 3.75);
        break;
    }

    $sql = $container['db'];

    $stmt = $sql->query("SELECT * FROM hajj WHERE id=".$haj_id);
    
    if ($stmt)
    {
        $haj = $stmt->fetch();
        
        $stmt = $sql->prepare("UPDATE hajj SET cash=:cash WHERE id=:id");

        $stmt->execute([
            'cash' => ($haj['cash'] + $money),
            'id' => $haj_id
        ]);

        $success_msg = "<center><h4 style='color:green;'>تمت العملية</h4></center>";
    }
}

?>


<div class="page">


    
<div class="main_1" style="width:97%;">

<div class="images"><img src="img/logo-wide.jpg"></div> 
<div class="name">حملة الإتحاد السعودي للأمن السيبراني والبرمجة والدرونز
<div class="campNo">الرقم : 056347</div>  
</div>

<div class="insidDiv">

<form role="search" class="search">
    <div class="search_control">
        <input type="search" class="site_search" name="q"
               placeholder="ابحث عن حاج..."
               aria-label="Search through site content">
        <button>البحث</button>
    </div>
</form>

</div>

    <div class="insidDivR">
<a href="myinfo.php"><div class="account"> رصيد الحملة : 10,000 </div></a>
</div>

    
<div class="userMenu">
    
</div>

</div><!-- Main END -->

<div class="chargMenu">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

<script>
function myFunction() {
    var x = document.getElementById("myDIV");
    if (x.style.display === "none") {
        x.style.display = "block";
    } else {
        x.style.display = "none";
    }
}
    
</script>

<script>
function myFunction() {
    var x = document.getElementById("myDIV");
    if (x.style.display === "none") {
        x.style.display = "block";
    } else {
        x.style.display = "none";
    }
}
    
</script>

<script>
function myFunction_1() {
    var x = document.getElementById("myDIV_1");
    if (x.style.display === "none") {
        x.style.display = "block";
    } else {
        x.style.display = "none";
    }
}
    
</script>

<script>
function myFunction_2() {
    var x = document.getElementById("myDIV_2");
    if (x.style.display === "none") {
        x.style.display = "block";
    } else {
        x.style.display = "none";
    }
}
    
</script>
    
<br>


<button onclick="myFunction()" class="sendMoney" id="show">إعادة الشحن</button>
<div id="myDIV" class="info" style="display:none;">

<form class="forms" action="" method="post">
<input type="text" class="textForm" name="money" placeholder="المبلغ"><br>
<input type="text" class="textForm" name="haj_id" placeholder="رقم الحاج">
<select name="currency" class="currency">
  <option value="riyal">الريال السعودي</option>
  <option value="dollar">الدولار الامريكي</option>
</select>
<br>
<input type="submit" name="charge" class="submit" value="تحويل">

    <?php
    if (isset($success_msg))
    {
        echo $success_msg;
    }
    
    ?>
    
    </form>
    

</div>


<button onclick="myFunction_1()" class="sendMoney" id="show1">خدمات الحاج</button>
<div id="myDIV_1" class="info" style="display:none;">
<div class="submit"><input type="radio" name="gender" value="x_o" class="larg radio">الهدي<br></div>
<div class="submit"><input type="radio" name="gender" value="x_d" class="larg radio">الأضحية<br></div>
<div class="submit"><input type="radio" name="gender" value="x_y" class="larg radio">الــدم<br></div>
</div>

<button onclick="myFunction_2()" class="sendMoney" id="show2">التبرع</button>
<div id="myDIV_2" class="info" style="display:none;">
<form class="forms" action="done,php">
<input type="text" class="textForm" name="number" placeholder="المبلغ"><br>
<input type="text" class="textForm" name="id" placeholder="رقم الحاج">
<br><input type="submit" class="submit" value="تحويل">
</form>
</div>

    
    

</div>    

 
</div>
<?php require 'footer.php';?>
