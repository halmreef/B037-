<?php require 'header.php';?>
<div class="page">

    
    

<div class="rmenu"><?php require 'menu.php';?></div>


<div class="myInfo">عدد العمليات : 10,000</div>   
<div class="myInfo">قيمة العمليات : 200,000</div>    
<div class="myInfo">عدد الحجاج : 3,000</div>    

<br>
<div class="main_3">
<div class="main_1" style="width: 46%;margin: 0 auto;float:right;margin-left:10px;">

<div class="hajj_info"><img src="img/analyse_1.png"></div>   
    
</div>

<div class="main_1" style="width: 46%;margin: 0 auto;margin-left:10px;float:right;">

<div class="hajj_info"><img src="img/analyse_2.png"></div>
    
</div>

</div>
    
</div>
<?php require 'footer.php';?>