<?php require 'header.php';?>
<div class="page">




    
    
<div class="main" style="width:97%;">

<div class="images"><img src="../img/recharger.png"></div> 
<div class="name">حملة النور
<div class="campNo">الرقم : 056347</div>  
</div>

    
<div class="userMenu">
    
<div class="alt1"><i class="fas fa-dollar-sign"></i> رصيدي : </div><div class="alt2">500SR</div>
<br>


<form id="sendMoney" name="sendMoney">
<input type="text" id="Price" value="">
</form>    
    
    
</div>


</div><!-- Main END -->

    
</div>
<?php require 'footer.php';?>