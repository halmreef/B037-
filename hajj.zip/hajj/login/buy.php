<?php

require 'header.php';

if ( isset($_GET['p']) )
{
    $current_cash = 0;
    switch ($_GET['p'])
    {
        case '1':
        $current_cash = 50;
        break;
        case '2':
        $current_cash = 45;
        break;
        case '3':
        $current_cash = 99;
        break;
    }
    $stmt = $container['db']->prepare("select cash from hajj where id=1857249568");
    $stmt->execute();
    $cash = $stmt->fetch();

    $cash = ($cash['cash'] - $current_cash);
    $stmt = $container['db']->query("update hajj set cash=".$cash);
    $buy = TRUE;
}

if (isset($buy) && $buy)
{
    echo "<h1 style='color:#fff'>تم الشراء</h1>";
}

?>




<div class="page">

    
    <div class="main" style="width:75%">


<div class="userMenu" style="margin-right:0">
    

</div>    

        
 <div class="table"><!--  Table Title Stat -->
<div class="tables w15">Product name</div><div class="tables w10">Buy</div>
</div><!--  Table Title END -->


<div class="table"><!--  Table Content Stat -->
    
<div class="tables w15" style="    width: 45%;">حلاق</div>
<div class="tables w15"><a href="buy.php?p=1">شراء</a></div>
<br>
<div class="tables w15"  style="    width: 45%;">وجبة غداء</div>
<div class="tables w15"><a href="buy.php?p=2">شراء</a></div>
        
        </div><!-- Main END -->




</div>
<?php require 'footer.php';?>
