<?php require 'header.php';?>



<div class="page">
    
<div class="main_1">

<div class="images"><img src="img/user.jpg"></div> 
<div class="name">الحاج سعود عبدالله القحطاني</div>
<div class="campNo">الرقم : 108809090908</div>    


    
<!-- <div class="userMenu">
    
<div class="alt1"><i class="fas fa-dollar-sign"></i> الرصيد : </div><div class="alt2">500SR</div>
<div class="alt1"><i class="fas fa-angle-double-left"></i> آخر شحن : </div><div class="alt2">22-1-2018</div>
<div class="alt1"><i class="fas fa-angle-double-left"></i>آخر عملية صرف :</div><div class="alt2">29-1-2018</div>
<div class="alt1"><i class="fas fa-angle-double-left"></i> الحد المتبقي : </div><div class="alt2">30SR</div>
    
</div> -->

<div class="insidDiv">
<a href="myinfo.php"><div class="account"><i class="fas fa-chart-line"></i> كشف حساب</div></a>
<a href="addMoney.php"><div class="addMoney"><i class="fas fa-plus"></i> إضافة رصيد</div></a>
<a href="myinfo.php"><div class="account"><i class="fas fa-hand-holding-usd"></i> تبـــرع </div></a>
</div>

<div class="insidDivR">
<a href="myinfo.php"><div class="account"> هدي </div></a>
<a href="myinfo.php"><div class="account"> أضحية </div></a>
<a href="myinfo.php"><div class="account"> دم </div></a>
</div>


<div class="alt">الرصيد : 500</div>
</div><!-- Main END -->
<br>
<div class="main_1" style="width: 30%;margin: 0 auto;">

<div class="hajj_info"><img src="img/info_1.png"></div>   
    
</div>

</div>
<?php require 'footer.php';?>
