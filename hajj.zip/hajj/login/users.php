<?php
if ( isset($_GET['p']) )
{
    $current_cash = 0;
    switch ($_GET['p'])
    {
        case '1':
        $current_cash = 50;
        break;
        case '2':
        $current_cash = 45;
        break;
        case '3':
        $current_cash = 99;
        break;
    }
    $stmt = $container['db']->prepare("select cash from hajj where id=1857249568");
    $stmt->execute();
    $cash = $stmt->fetch();

    $cash = ($cash['cash'] - $current_cash);
    $stmt = $container['db']->query("update hajj set cash=".$cash);
    $buy = TRUE;
}

if (isset($buy) && $buy)
{
    echo "<h1>تم الشراء</h1>";
}

?>



<a href="buy.php?p=1">Product 1</a>
<a href="buy.php?p=2">Product 2</a>
<a href="buy.php?p=3">Product 3</a>


<?php require 'header.php';?>

<div class="page">

<div class="menu">
<ul>
<li><a href="admin.php">الرئيسية</a></li>
<li><a href="users.php">الحجاج</a></li>
<li><a href="users.php">مقدمي الخدمة</a></li>
<li><a href="users.php">مدراء الحملات</a></li>
</ul>
</div>
    
    <div class="main" style="width:75%">


<div class="userMenu" style="margin-right:0">
    

</div>    

        
 <div class="table"><!--  Table Title Stat -->
<div class="tables w10">Id</div><div class="tables w15">Name</div><div class="tables w10">Buy</div>
</div><!--  Table Title END -->


<div class="table"><!--  Table Content Stat -->
    
<div class="tables w10"> <?php echo $haj['id'] ?></div>
<div class="tables w15"> <?php echo $haj['first_name'] ?></div>
<div class="tables w15"><?php echo $haj['last_name'] ?></div>
        
</div><!-- Main END -->




</div>
<?php require 'footer.php';?>
