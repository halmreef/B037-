<?php


try {
    $config = $container['config'];
    $dbh = new PDO(
        $config->get('db')['pdo']['dsn'],
        $config->get('db')['pdo']['user'],
        $config->get('db')['pdo']['password']
    );
} catch (PDOException $e) {
    echo 'Connection failed: ' . $e->getMessage();
}