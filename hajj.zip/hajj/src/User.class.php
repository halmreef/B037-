<?php

class User {

    protected $userId;

    public function __construct($userId)
    {
        $this->user_id = $userId;
    }

    public function isLoggedIn()
    {
        return (bool) ($this->userId != null);
    }
}