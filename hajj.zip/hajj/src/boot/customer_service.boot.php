<?php

require_once("../boot.php");

if ( ! $container['user']->isLoggedIn() )
{
    header("Location: http://127.0.0.1/hajj/web_root/login.php?redirect_to=".$_SERVER['REQUEST_URI']);
    die();
}

// if ( $container['user']->has('ROLE_CUSTOMER_SERVICE') )