<?php

class Config {

    protected $configFile;

    protected $configs;

    public function __construct($configFile)
    {
        $this->configFile = $configFile;
        $this->loadConfigFile($this->configFile);
    }

    protected function loadConfigFile($configFile)
    {
        require_once($configFile);
        $this->configs = $config;
    }

    public function has($key)
    {
        return (bool) array_key_exists($key, $this->configs);
    }

    public function get($key)
    {
        if ( $this->has($key) )
        {
            return $this->configs[$key];
        }
        return null;
    }

    public function set($key, $value)
    {
        $this->configs[$key] = $value;
    }

}