<?php

session_start();

define('ROOTPATH', $_SERVER['DOCUMENT_ROOT']."/hajj\/");

require_once(ROOTPATH."config/constants.php");
require_once("Config.class.php");
require_once("User.class.php");

$container = [];

$container['config'] = new Config(realpath(ROOTPATH."config/config.php"));

require_once("database.php");

$container['db'] = $dbh;
unset($dbh);

$container['user'] = new User(($_SESSION['user_id'] ?? null));