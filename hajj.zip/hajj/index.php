<?php require 'header.php';?>
<div class="page">


    
<div class="loginpage">
<a href="index.php"><div class="logo"><img src="img/logo.png"></div></a>


<div class="login">
    
<form class="forms" action="login">
<div class="title"><h2>تسجيل الدخول</h2></div>
<input type="text" class="textForm userbg" name="username" placeholder="رقم الهوية"><br>
<input type="password" class="textForm passbg" name="psw" placeholder="كلمة السر">
<br>
<a href="#">استعادة الرقم السري</a>
<input type="submit" class="submit" value="دخول">

</form>
</div>
    
</div>

<div class="logos">
<img src="img/hajj.png">
<img src="img/2030.png">
</div>


</div>
<?php require 'footer.php';?>