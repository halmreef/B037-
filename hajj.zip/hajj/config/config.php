<?php

$config['db'] = 
[
    'pdo' => [
        'dsn' => 'mysql:dbname=hajjapp;host=127.0.0.1',
        'host' => '127.0.0.1', 
        'user' => 'root',
        'password' => '',
        'dbname' => 'hajjapp',
    ]
];