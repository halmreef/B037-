<?php

// define('ROOTPATH', realpath('../').DIRECTORY_SEPARATOR);