<?php

// View data

require_once("../../src/boot.php");

$haj = null;

if ( ! array_key_exists("haj_id", $_GET)   )
{
    die("User id is wrong");
}

try {
    $haj_id = $_GET['haj_id'];
    $sql = $container['db'];

    // $stmt = $sql->prepare("SELECT * FROM haj WHERE id=?");

    // $stmt->execute([$haj_id]);
    // $haj = $stmt->fetch();

    // $haj = $sql->query("SELECT id FROM haj;");

    // var_dump($haj);

    $stmt = $sql->prepare("SELECT * FROM hajj;");

    $stmt->execute();

    $haj = $stmt->fetch();

    // select a particular user by id
    // $stmt = $pdo->prepare("SELECT * FROM users WHERE id=:id");
    // $stmt->execute(['id' => $id]); 
    // $user = $stmt->fetch();

    if ( $haj == false )
    {
        die("User with Id ($haj_id) is not exists.");
    }
} catch (Exception $e)
{
    // Comment this line in production
    echo $e->getMessage();

    // header("Location: Http://localhost/hajj/web_root/");
    exit;
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>View Haj Data</title>
</head>
<body>
    <table>
        <tr>
            <td>ID</td>
            <td><strong>
                <?php echo $haj['id'] ?>
            </strong></td>
        </tr>
        <tr>
            <td>First Name</td>
            <td><strong>
                <?php echo $haj['first_name'] ?>
            </strong></td>
        </tr>
        <tr>
            <td>Last Name</td>
            <td><strong>
                <?php echo $haj['last_name'] ?>
            </strong></td>
        </tr>
        <tr>
            <td>Email</td>
            <td><strong>
                <?php echo $haj['email'] ?>
            </strong></td>
        </tr>
        <tr>
            <td>Password</td>
            <td><strong>
                <?php echo $haj['password'] ?>
            </strong></td>
        </tr>
        <tr>
            <td>Cash</td>
            <td><strong>
                <?php echo $haj['cash'] ?>
            </strong></td>
        </tr>
        <tr>
            <td>Limit a day</td>
            <td><strong>
                <?php echo $haj['limit_a_day'] ?>
            </strong></td>
        </tr>
<!--
        <tr>
            <td colspan="2">
                <a href="#">
                    <button>Back</button>
                </a>
            </td>
        </tr>
-->
    </table>
</body>
</html>