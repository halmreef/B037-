<?php

require_once("../../src/boot.php");

$sql = $container['db'];

$stmt = $sql->query("SELECT * FROM hajj;");
$records = $stmt->fetchAll();

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <table>
        <thead>
            <tr>
                <td>ID</td>
                <td>First Name</td>
                <td>Last Name</td>
                <td>Email</td>
                <td>Password</td>
                <td>Cash</td>
                <td>Limit a day</td>
                <td>Actions</td>
            </tr>
        </thead>
        <tbody>
            <?php
            foreach ($records as $record) :
                echo "<tr>";
                    echo "<td>".$record['id']."</td>";
                    echo "<td>".$record['first_name']."</td>";
                    echo "<td>".$record['last_name']."</td>";
                    echo "<td>".$record['email']."</td>";
                    echo "<td>".$record['password']."</td>";
                    echo "<td>".$record['cash']."</td>";
                    echo "<td>".$record['limit_a_day']."</td>";
                    echo "<td><a href='http://localhost/hajj/web_root/demo/step2.php?haj_id=".$record['id']."'><button>View Details</button></a></td>";
                echo "</tr>";
            endforeach;
            ?>
        </tbody>
    </table>
</body>
</html>

