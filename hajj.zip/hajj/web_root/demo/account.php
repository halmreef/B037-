<?php

// View data

require_once("header.php");

$haj = null;

// if ( ! array_key_exists("haj_id", $_GET)   )
// {
//     die("User id is wrong");
// }

try {
    // $haj_id = $_GET['haj_id'];
    $haj_id = 1857249568;
    $sql = $container['db'];

    // $stmt = $sql->prepare("SELECT * FROM haj WHERE id=?");

    // $stmt->execute([$haj_id]);
    // $haj = $stmt->fetch();

    // $haj = $sql->query("SELECT id FROM haj;");

    // var_dump($haj);

    $stmt = $sql->prepare("SELECT * FROM hajj;");

    $stmt->execute();

    $haj = $stmt->fetch();

    // select a particular user by id
    // $stmt = $pdo->prepare("SELECT * FROM users WHERE id=:id");
    // $stmt->execute(['id' => $id]); 
    // $user = $stmt->fetch();

    if ( $haj == false )
    {
        die("User with Id ($haj_id) is not exists.");
    }
} catch (Exception $e)
{
    // Comment this line in production
    echo $e->getMessage();

    // header("Location: Http://localhost/hajj/web_root/");
    exit;
}

?>

 <div class="table"><!--  Table Title Stat -->
<div class="tables w10">Id</div><div class="tables w15">Fist Name</div><div class="tables w15">Last Name</div><div class="tables w20">Email</div><div class="tables w10">Password</div><div class="tables w10">Cash</div><div class="tables w10">Limit a Day</div>
</div><!--  Table Title END -->


<div class="table"><!--  Table Content Stat -->
    
<div class="tables w10"> <?php echo $haj['id'] ?></div>
<div class="tables w15"> <?php echo $haj['first_name'] ?></div>
<div class="tables w15"><?php echo $haj['last_name'] ?></div>
<div class="tables w20"> <?php echo $haj['email'] ?></div>
<div class="tables w10"><?php echo $haj['password'] ?></div>
<div class="tables w10"><?php echo $haj['cash'] ?></div>
<div class="tables w10"><?php echo $haj['limit_a_day'] ?></div>

        
</div><!-- Main END -->
