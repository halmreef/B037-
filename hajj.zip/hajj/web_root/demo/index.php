<?php include('header.php'); ?>

<div class="page">




    
    
<div class="info" style="    width: 30%;margin:50px auto">
    
    
    


    

    
</div><!-- Main END -->

 
</div>

<?php include('footer.php'); ?>