<?php require 'header.php';?>
<div class="page">

<div class="menu">
<ul>
<li><a href="admin.php">الرئيسية</a></li>
<li><a href="users.php">الحجاج</a></li>
<li><a href="users.php">مقدمي الخدمة</a></li>
<li><a href="users.php">مدراء الحملات</a></li>
</ul>
</div>
    
    <div class="main" style="width:75%">


<div class="userMenu" style="margin-right:0">
    

</div>    

        
 <div class="table"><!--  Table Title Stat -->
<div class="tables w10">Id</div><div class="tables w15">Fist Name</div><div class="tables w15">Last Name</div><div class="tables w20">Email</div><div class="tables w10">Password</div><div class="tables w10">Cash</div><div class="tables w10">Limit a Day</div>
</div><!--  Table Title END -->


<div class="table"><!--  Table Content Stat -->
    
<div class="tables w10"> <?php echo $haj['id'] ?></div>
<div class="tables w15"> <?php echo $haj['first_name'] ?></div>
<div class="tables w15"><?php echo $haj['last_name'] ?></div>
<div class="tables w20"> <?php echo $haj['email'] ?></div>
<div class="tables w10"><?php echo $haj['password'] ?></div>
<div class="tables w10"><?php echo $haj['cash'] ?></div>
<div class="tables w10"><?php echo $haj['limit_a_day'] ?></div>

        
</div><!-- Main END -->




</div>
<?php require 'footer.php';?>