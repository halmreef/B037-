<?php

// Get GET variable

// - bill number
// - shop name
// - price
// - user id

// - Is valid user?
// - Has cash?
// - discount
// - return to step3 page

$bill_number = isset($_GET['bill_number']) ? $_GET['bill_number'] : null;
$shop_name = isset($_GET['shop_name']) ? $_GET['shop_name'] : null;
$price = isset($_GET['price']) ? $_GET['price'] : null;
$haj_id = isset($_GET['haj_id']) ? $_GET['haj_id'] : null;

if ( 
    is_null($bill_number)
    || is_null($shop_name)
    || is_null($price)
    || is_null($haj_id)
 )
 die("Missing data");

 require_once("../../src/boot.php");

 $sql = $container['db'];

 $stmt = $sql->prepare("SELECT * FROM hajj WHERE id=:id");
 $stmt->execute(['id' => $haj_id]);
 $haj = $stmt->fetch();

 if ( ! $haj )
 {
     die("Invalid Haj Id");
 }

 if ( $price > $haj['cash'] )
 {
     die("You don't have enough money.");
 }


$stmt = $sql->prepare("UPDATE hajj SET cash=:cash WHERE id=:id");

$stmt->execute([
    'cash' => ($haj['cash'] - $price),
    'id' => $haj['id']
]);

header("Location: http://localhost/hajj/web_root/demo/step3.php");  