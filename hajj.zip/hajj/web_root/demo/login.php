<?php

require_once("../src/boot.php");

if ( isset($_SESSION['user_id']) )
{
    header("Location: http://127.0.0.1/hajj/web_root/demo/");
    die();
}
elseif ( isset($_POST['login']) )
{
    $login_error = false;

    if ( !isset($_POST['user_string']) || $_POST['user_string'] != '12345678' )
    {
        $login_error = TRUE;
    }
    if ( !isset($_POST['password']) || $_POST['password'] != 'secret' )
    {
        $login_error = TRUE;
    }

    if ( !$login_error )
    {
        $_SESSION['user_id'] = 234;
        header("Location: http://127.0.0.1/hajj/web_root/demo/");
        die();
    }
}

?>

<?php include('header.php'); ?>

<div class="page">




    
    
<div class="info" style="    width: 30%;margin:50px auto">
    
    
<form class="forms" action="" method="post">
<input type="text" class="textForm" name="user_string" placeholder="Username"><br>
<input type="password" class="textForm" name="password" placeholder="Password">
<br>
<input type="submit" name="login" class="submit" value="Login">

</form>  
    <?php
    if (isset($login_error))
    {
        $login_error = "Username/Password is wrong";
    }
    ?>
    
</div>


    

    
</div><!-- Main END -->

 
</div>

<?php include('footer.php'); ?>