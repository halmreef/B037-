<?php

// Fill single hajj data

require_once("../../src/boot.php");

$dummy_data = 
[
    'haj1' => 
    [
        'id' => 1857249568,
        'first_name' => 'Mohammed',
        'last_name' => 'Aldayel',
        'email' => 'mohammed@email.com',
        'password' => 'secret',
        'cash' => 500,
        'limit_a_day' => 30,
    ],
];

$sql = $container['db'];

$stmt = $sql->prepare("INSERT INTO `hajj` (id, first_name, last_name, email, password, cash, limit_a_day) VALUES 
                                          (:id, :first_name, :last_name, :email, :password, :cash, :limit_a_day)");

foreach ($dummy_data as $user)
{
    $stmt->bindParam(':id'          , $user['id']);
    $stmt->bindParam(':first_name'  , $user['first_name']);
    $stmt->bindParam(':last_name'   , $user['last_name']);
    $stmt->bindParam(':email'       , $user['email']);
    $stmt->bindParam(':password'    , $user['password']);
    $stmt->bindParam(':cash'        , $user['cash']);
    $stmt->bindParam(':limit_a_day' , $user['limit_a_day']);

    $stmt->execute();
}

echo "Dummy data inserted";