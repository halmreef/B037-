<?php

require_once("../../src/boot.php");

if ( isset($_POST['charge']) )
{
    $money = $_POST['money'];
    $haj_id = $_POST['haj_id'];

    $sql = $container['db'];

    $stmt = $sql->query("SELECT * FROM hajj WHERE id=".$haj_id);
    $haj = $stmt->fetch();
    
    $stmt = $sql->prepare("UPDATE hajj SET cash=:cash WHERE id=:id");

    $stmt->execute([
        'cash' => ($haj['cash'] + $money),
        'id' => $haj_id
    ]);

    $success_msg = "<center><h4 style='color:green;'>تمت العملية</h4></center>";
}

?>

<!DOCTYPE html>
<html dir="rtl" lang="ar-sa">
<head>
<title>هاكثون الحج</title>
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.2.0/css/all.css" integrity="sha384-hWVjflwFxL6sNzntih27bfxkr27PmbbK/iSvJ+a4+0owXq79v+lsFkW54bOGbiDQ" crossorigin="anonymous">
<script src="/hajj/web_root/js/bootstrap.js"></script>
<link href="/hajj/web_root/css/style.css" rel="stylesheet">

<body>
    
<div class="header">
<a href="../index.php"><div class="logo"><img src=/hajj/web_root/img/logo.png></div></a>
<div class="navmenu">
<a href="index.php">الرئيسية</a>
<a href="index.php">الحاج</a>
<a href="service.php">مقدم خدمة</a>
<a href="rechrger.php">مدير الحملة</a>
<a href="admin.php">مدير النظام</a>

</div>
    
    
</div>

    

<div class="page">




    
    
<div class="info" style="    width: 30%;margin:50px auto">
    
    
<form class="forms" action="http://localhost/hajj/web_root/demo/recharge.php" method="post">
<input type="text" class="textForm" name="money" placeholder="المبلغ"><br>
<input type="text" class="textForm" name="haj_id" placeholder="رقم الحاج">
<br>
<input type="submit" name="charge" class="submit" value="تحويل">

</form>  
    <?php
    if (isset($success_msg))
    {
        echo $success_msg;
    }
    ?>
    
</div>


    

    
</div><!-- Main END -->

 
</div>

</body></html>