<?php include('header.php'); 


if ( isset($_POST['charge']) )
{
    $money = $_POST['money'];
    $haj_id = $_POST['haj_id'];
    $currency = $_POST['currency'];

    // Covert money
    switch ($currency)
    {
        case 'dollar':
            $money = ($money * 3.75);
        break;
    }

    $sql = $container['db'];

    $stmt = $sql->query("SELECT * FROM hajj WHERE id=".$haj_id);
    
    if ($stmt)
    {
        $haj = $stmt->fetch();
        
        $stmt = $sql->prepare("UPDATE hajj SET cash=:cash WHERE id=:id");

        $stmt->execute([
            'cash' => ($haj['cash'] + $money),
            'id' => $haj_id
        ]);

        $success_msg = "<center><h4 style='color:green;'>تمت العملية</h4></center>";
    }
}

?>


<div class="page">




    
    
<div class="info" style="    width: 30%;margin:50px auto">
    
    
<form class="forms" action="" method="post">
<input type="text" class="textForm" name="money" placeholder="المبلغ"><br>
<input type="text" class="textForm" name="haj_id" placeholder="رقم الحاج">
<select name="currency" class="currency">
  <option value="riyal">الريال السعودي</option>
  <option value="dollar">الدولار الامريكي</option>
</select>
<br>
<input type="submit" name="charge" class="submit" value="تحويل">

</form>  
    <?php
    if (isset($success_msg))
    {
        echo $success_msg;
    }
    ?>
    
</div>


    

    
</div><!-- Main END -->

 
</div>

<?php include('footer.php'); ?>