<?php

require_once("../src/boot.php");

if ( isset($_SESSION['user_id']) )
{
    header("Location: http://127.0.0.1/hajj/web_root/");
    die();
}
elseif ( isset($_POST['login']) )
{
    $login_error = false;

    if ( !isset($_POST['user_string']) || $_POST['user_string'] != '12345678' )
    {
        $login_error = TRUE;
    }
    if ( !isset($_POST['password']) || $_POST['password'] != 'secret' )
    {
        $login_error = TRUE;
    }

    if ( !$login_error )
    {
        $_SESSION['user_id'] = 234;
        header("Location: http://127.0.0.1/hajj/web_root/");
        die();
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Login</title>
</head>
<body>
    <form action="" method="post">
        <table>
            <tr>
                <td colspan="2">
                    <?php
                    if ( isset($login_error) && $login_error )
                    {
                        echo "Username/Password is wrong";
                    }
                    ?>
                </td>
            </tr>
            <tr>
                <td>ID</td>
                <td>
                    <input type="text" name="user_string" value="" >
                </td>
            </tr>
            <tr>
                <td>Password</td>
                <td>
                    <input type="password" name="password" >
                </td>
            </tr>
            <tr>
                <td><input type="submit" name="login" value="Login"></td>
            </tr>
        </table>
    </form>
</body>
</html>