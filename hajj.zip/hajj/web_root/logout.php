<?php

require_once("../src/boot.php");

session_destroy();
header("Location: http://127.0.0.1/hajj/web_root/login.php");
die();