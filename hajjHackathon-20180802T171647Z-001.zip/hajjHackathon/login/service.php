<?php require 'header.php';?>
<div class="page">




    
    
<div class="main" style="width:97%;">

<div class="images"><img src="../img/food.png"></div> 
<div class="name">مطعم مكة المكرمة
<div class="campNo">الرقم : 90475</div>  
</div>

    
<div class="userMenu">
    
<div class="alt1"><i class="fas fa-dollar-sign"></i> الرصيد : </div><div class="alt2">500SR</div>
<br>
<a href="addMoney.php"><div class="sendMoney">تصدير المبلغ</div></a>

    
</div>    

    
</div><!-- Main END -->

<div class="prodact"><!-- Start -->
<img src="../img/food.png">

<div class="alt_1">المحصل</div><div class="alt_2">200,000 SR</div>
<div class="alt_1">النسبة</div><div class="alt_2">500%</div>
<div class="alt_1">المخزون</div><div class="alt_2">1000 وجبة </div>

    
<a href="#"><i class="far fa-trash-alt" title="حذف"></i></a>
<a href="#"><i class="fas fa-edit" title="تعديل"></i></a>

</div><!-- Start -->

<div class="prodact"><!-- Start -->
<img src="../img/food.png">

<div class="alt_1">المحصل</div><div class="alt_2">200,000 SR</div>
<div class="alt_1">النسبة</div><div class="alt_2">500%</div>
<div class="alt_1">المخزون</div><div class="alt_2">1000 وجبة </div>

    
<a href="#"><i class="far fa-trash-alt" title="حذف"></i></a>
<a href="#"><i class="fas fa-edit" title="تعديل"></i></a>

</div><!-- Start -->
    
    
<div class="prodact"><!-- Start -->
<img src="../img/food.png">

<div class="alt_1">المحصل</div><div class="alt_2">200,000 SR</div>
<div class="alt_1">النسبة</div><div class="alt_2">500%</div>
<div class="alt_1">المخزون</div><div class="alt_2">1000 وجبة </div>

    
<a href="#"><i class="far fa-trash-alt" title="حذف"></i></a>
<a href="#"><i class="fas fa-edit" title="تعديل"></i></a>

</div><!-- Start -->
    
    
<div class="prodact"><!-- Start -->
<img src="../img/food.png">

<div class="alt_1">المحصل</div><div class="alt_2">200,000 SR</div>
<div class="alt_1">النسبة</div><div class="alt_2">500%</div>
<div class="alt_1">المخزون</div><div class="alt_2">1000 وجبة </div>

    
<a href="#"><i class="far fa-trash-alt" title="حذف"></i></a>
<a href="#"><i class="fas fa-edit" title="تعديل"></i></a>

</div><!-- Start -->
    
    
    
<div class="prodact"><!-- Start -->
<img src="../img/food.png">

<div class="alt_1">المحصل</div><div class="alt_2">200,000 SR</div>
<div class="alt_1">النسبة</div><div class="alt_2">500%</div>
<div class="alt_1">المخزون</div><div class="alt_2">1000 وجبة </div>

    
<a href="#"><i class="far fa-trash-alt" title="حذف"></i></a>
<a href="#"><i class="fas fa-edit" title="تعديل"></i></a>

</div><!-- Start -->

    
<a href="addMoney.php"><div class="sendMoney">إضافة منتج</div></a>

    
</div>
<?php require 'footer.php';?>
