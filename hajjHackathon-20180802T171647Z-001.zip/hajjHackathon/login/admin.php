<?php require 'header.php';?>
<div class="page">


<div class="menu">
<ul>
<li><a href="#">الرئيسية</a></li>
<li><a href="users.php">الحجاج</a></li>
<li><a href="users.php">مقدمي الخدمة</a></li>
<li><a href="users.php">مدراء الحملات</a></li>
</ul>
</div>

    
    
<div class="main">

<div class="images"><img src="img/manager.png"></div> 
<div class="name">مدير النظام
<div class="campNo">الرقم : 1 </div>    
</div>


    
<div class="userMenu">
    
<div class="alt1"><i class="fas fa-angle-double-left"></i> آخر دخول : </div><div class="alt2">22-1-2018</div>
    
</div>    

    
</div><!-- Main END -->

</div>
<?php require 'footer.php';?>
