<?php require 'header.php';?>
<div class="page">




    
    
<div class="main" style="width:97%;">

<div class="images"><img src="../img/recharger.png"></div> 
<div class="name">حملة النور
<div class="campNo">الرقم : 056347</div>  
</div>

    
<div class="userMenu">
    
<div class="alt1"><i class="fas fa-dollar-sign"></i> رصيدي : </div><div class="alt2">500SR</div>
<br>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script>
$(document).ready(function(){
    $("button").click(function(){
        $(".info").show(800);
    });
});
</script>

    
</div>

    <button class="sendMoney" id="show">تحويل رصيد</button>
    
<div class="info" style="display:none;">
    
    
<form class="forms" action="done,php">
<input type="text" class="textForm" name="number" placeholder="المبلغ"><br>
<input type="text" class="textForm" name="id" placeholder="رقم الحاج">
<br>
<input type="submit" class="submit" value="تحويل">

</form>  
    
    
</div>


    

    
</div><!-- Main END -->

 
</div>
<?php require 'footer.php';?>
