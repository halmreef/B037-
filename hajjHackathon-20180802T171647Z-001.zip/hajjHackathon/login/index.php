<?php require 'header.php';?>
<div class="page">




    
    
<div class="main">

<div class="images"><img src="img/user.jpg"></div> 
<div class="name">الحاج سعود عبدالله القحطاني
<div class="campNo">الرقم : 108809090908</div>    
</div>


    
<div class="userMenu">
    
<div class="alt1"><i class="fas fa-dollar-sign"></i> الرصيد : </div><div class="alt2">500SR</div>
<div class="alt1"><i class="fas fa-angle-double-left"></i> آخر شحن : </div><div class="alt2">22-1-2018</div>
<div class="alt1"><i class="fas fa-angle-double-left"></i>آخر عملية صرف :</div><div class="alt2">29-1-2018</div>
<div class="alt1"><i class="fas fa-angle-double-left"></i> الحد المتبقي : </div><div class="alt2">30SR</div>
    
</div>    

    
</div><!-- Main END -->

<div class="content">
<div class="title"><h2>مصروفاتي</h2></div>
<a href="myinfo.php"><img src="img/Graph.png"></a>
</div>
    
<div class="content">
<div class="title"><h2>كشف الحساب</h2></div>  
<img src="img/Graph_1.png">
</div>

<a href="addMoney.php"><div class="addMoney">إضافة رصيد</div></a>

</div>
<?php require 'footer.php';?>
