<!DOCTYPE html>
<html dir="rtl" lang="ar-sa">
<head>
<title>هاكثون الحج</title>
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.2.0/css/all.css" integrity="sha384-hWVjflwFxL6sNzntih27bfxkr27PmbbK/iSvJ+a4+0owXq79v+lsFkW54bOGbiDQ" crossorigin="anonymous">
<script src="js/bootstrap.js"></script>
<link href="css/style.css" rel="stylesheet">

<body>
    
<div class="header">
<a href="../index.php"><div class="logo"><img src=../img/logo.png></div></a>
<div class="navmenu">
<a href="index.php">الرئيسية</a>
<a href="index.php">الحاج</a>
<a href="service.php">مقدم خدمة</a>
<a href="rechrger.php">مدير الحملة</a>
<a href="admin.php">مدير النظام</a>

</div>
    
    
</div>

    