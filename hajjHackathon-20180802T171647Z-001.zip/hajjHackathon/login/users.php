<?php require 'header.php';?>
<div class="page">

<div class="menu">
<ul>
<li><a href="admin.php">الرئيسية</a></li>
<li><a href="users.php">الحجاج</a></li>
<li><a href="users.php">مقدمي الخدمة</a></li>
<li><a href="users.php">مدراء الحملات</a></li>
</ul>
</div>
    
    <div class="main" style="width:75%">


<div class="userMenu" style="margin-right:0">
    
<div class="alt1"><i class="fas fa-angle-double-left"></i> الاسم</div><div class="alt2">تاريخ التسجيل</div><div class="alt3">إدارة</div>
<div class="alt1"><i class="fas fa-angle-double-left"></i> سعود عبدالله القحطاني </div><div class="alt2">1-1-2001</div><div class="alt3"><a href="#"><i class="far fa-trash-alt" title="حذف"></i></a><a href="#"><i class="fas fa-edit" title="تعديل"></i></a></div>
<div class="alt1"><i class="fas fa-angle-double-left"></i> سعود عبدالله القحطاني </div><div class="alt2">1-1-2001</div><div class="alt3"><a href="#"><i class="far fa-trash-alt" title="حذف"></i></a><a href="#"><i class="fas fa-edit" title="تعديل"></i></a></div>

    <div class="alt1"><i class="fas fa-angle-double-left"></i> سعود عبدالله القحطاني </div><div class="alt2">1-1-2001</div><div class="alt3"><a href="#"><i class="far fa-trash-alt" title="حذف"></i></a><a href="#"><i class="fas fa-edit" title="تعديل"></i></a></div>

    <div class="alt1"><i class="fas fa-angle-double-left"></i> سعود عبدالله القحطاني </div><div class="alt2">1-1-2001</div><div class="alt3"><a href="#"><i class="far fa-trash-alt" title="حذف"></i></a><a href="#"><i class="fas fa-edit" title="تعديل"></i></a></div>

    <div class="alt1"><i class="fas fa-angle-double-left"></i> سعود عبدالله القحطاني </div><div class="alt2">1-1-2001</div><div class="alt3"><a href="#"><i class="far fa-trash-alt" title="حذف"></i></a><a href="#"><i class="fas fa-edit" title="تعديل"></i></a></div>

</div>    

    
</div><!-- Main END -->




</div>
<?php require 'footer.php';?>
