<?php require 'header.php';?>
<div class="page">

<a href="index.php"><div class="logo"><img src="img/logo.png"></div></a>

<div class="login">
    
<form class="forms" action="login">>
<div class="title"><h2>تسجيل الدخول</h2></div>
<input type="text" class="textForm" name="username" placeholder="رقم الهوية"><br>
<input type="password" class="textForm" name="psw" placeholder="كلمة السر">
<br>
<a href="#">استعادة الرقم السري</a>
<input type="submit" class="submit" value="دخول">

</form>

</div>    


</div>
<?php require 'footer.php';?>